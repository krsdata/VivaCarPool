package au.com.vivcar.model;

public class RideBooking {

	private String bookId;
	private String rideId;
	private String seats;
	private String from;
	private String to;
	
	
}
