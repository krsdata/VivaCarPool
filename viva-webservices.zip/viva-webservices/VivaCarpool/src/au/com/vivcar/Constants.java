package au.com.vivcar;

public class Constants {

	public static String NOTIF_STAGE="";
	
	/* Table Names */
	
	public static String TABLE_USERS ="users";
	
	public static String TABLE_RIDES ="rides";
	
	public static String TABLE_RIDE_BOOKINGS ="ridebookings";
	
	public static String TABLE_NOTIFICATIONS ="notifications";
	
	/* End of Table Names */
	
	
	/* User Table Column Names */
	
	/* End of User Table Column Names */
	
	
	/* User Table Column Names */
	
	/* End of User Table Column Names */
	
	
	/* User Table Column Names */
	
	/* End of User Table Column Names */
	
	
	/* User Table Column Names */
	
	/* End of User Table Column Names */
	
	
	/* User Table Column Names */
	
	/* End of User Table Column Names */
	
}
